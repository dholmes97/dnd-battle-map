const fs = require('node:fs');
const path = require('node:path');
const { runWebExt } = require('./web-ext.cjs');

const root = path.resolve(__dirname, '..');
const sourceInputs = [
    'images', 'libs', 'src', 'scripts', 'tests', 'refresh-regression.test.cjs', '.node-version',
    'package.json', 'package-lock.json', 'options.html', 'options.css',
    'manifest.json', 'manifest_ff.json', 'popup.html', 'gulpfile.js',
    'default_popup.html', 'README.md', 'LICENSE', 'LICENSE.MIT'
];

function packageExtension(target) {
    if (!['chrome', 'firefox', 'src'].includes(target)) {
        throw new Error('Choose chrome, firefox, or src');
    }
    const { version } = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
    if (!/^\d+\.\d+\.\d+(?:-[a-zA-Z0-9.-]+)?$/.test(version)) {
        throw new Error('Invalid package version');
    }
    const artifacts = path.join(root, 'build', 'artifacts');
    fs.mkdirSync(artifacts, { recursive: true });
    let stage;
    try {
        // Archive the actual reviewed working files, including uncommitted fixes.
        // The fixed allowlist excludes Git metadata, profiles, credentials and dependencies.
        if (target === 'src') {
            stage = fs.mkdtempSync(path.join(root, 'build', 'source-'));
            for (const input of sourceInputs) {
                fs.cpSync(path.join(root, input), path.join(stage, input), { recursive: true });
            }
        }
        runWebExt([
            'build', '--no-config-discovery',
            '--source-dir', stage || path.join(root, 'build', target),
            '--artifacts-dir', artifacts,
            '--filename', `beyond_20-${version}-${target}.zip`, '--overwrite-dest',
            ...(target === 'src' ? ['--ignore-files', '!.node-version'] : [])
        ]);
    } finally {
        if (stage) fs.rmSync(stage, { recursive: true, force: true });
    }
}

module.exports = { packageExtension, sourceInputs };
if (require.main === module) packageExtension(process.argv[2]);
