const path = require('node:path');
const { spawnSync } = require('node:child_process');

const root = path.resolve(__dirname, '..');

function runWebExt(args) {
    const result = spawnSync(process.execPath, [
        path.join(root, 'node_modules', 'web-ext', 'bin', 'web-ext.js'),
        ...args
    ], {
        cwd: root, stdio: 'inherit', shell: false,
        env: {
            ...process.env,
            NO_UPDATE_NOTIFIER: '1',
            XDG_CONFIG_HOME: path.join(root, '.dependency-security', 'config'),
            XDG_CACHE_HOME: path.join(root, '.dependency-security', 'cache')
        }
    });
    if (result.error) throw result.error;
    if (result.status !== 0) throw new Error(`web-ext failed (${result.status ?? result.signal})`);
}

module.exports = { runWebExt };
if (require.main === module) runWebExt(process.argv.slice(2));
