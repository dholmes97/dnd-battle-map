const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { packageExtension } = require('../scripts/package.cjs');
const root = path.resolve(__dirname, '..');

test('packaging rejects unknown targets before creating output', () => {
    assert.throws(() => packageExtension('../outside'), /Choose chrome, firefox, or src/);
});

function files(directory) {
    return fs.readdirSync(directory, { withFileTypes: true }).flatMap(entry => {
        if (entry.name.startsWith('.')) return [];
        const name = path.join(directory, entry.name);
        return entry.isDirectory() ? files(name) : [name];
    });
}

for (const target of ['chrome', 'firefox']) {
    test(`${target} build preserves binary assets and uses the correct manifest`, () => {
        for (const directory of ['images', 'libs']) {
            for (const source of files(path.join(root, directory))) {
                const output = path.join(root, 'build', target, path.relative(root, source));
                assert.deepEqual(fs.readFileSync(output), fs.readFileSync(source), output);
            }
        }
        const manifest = target === 'firefox' ? 'manifest_ff.json' : 'manifest.json';
        assert.deepEqual(
            fs.readFileSync(path.join(root, 'build', target, 'manifest.json')),
            fs.readFileSync(path.join(root, manifest))
        );
    });
}

test('browser bundles contain the current working source rather than committed HEAD', () => {
    for (const target of ['chrome', 'firefox']) {
        for (const [bundle, source] of [
            ['background.js', 'src/extension/background.js'],
            ['generic_site.js', 'src/generic-site/content-script.js']
        ]) {
            const output = fs.readFileSync(path.join(root, 'build', target, 'dist', bundle), 'utf8');
            assert.ok(output.includes(fs.readFileSync(path.join(root, source), 'utf8')));
        }
    }
});
